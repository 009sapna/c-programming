#include <stdio.h>
int main(){
int a;
int b;
int c;
printf("enter the angel of triangle");
scanf("%d",&a);
printf("enter the angle of triangle");
scanf("%d",&b);
printf("enter the angle of triangle");
scanf("%d",&c);
if (a+b+c==180){
    printf("valid triangle");
}else{
printf("not valid");
 } }
