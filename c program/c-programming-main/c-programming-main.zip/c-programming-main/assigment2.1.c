#include <stdio.h>
int main(){
        float centigrade;
        float fahrenheit;
        printf("enter the temperature in centigrade");
        scanf("%f",&centigrade);

        fahrenheit=(9*centigrade)/5+32;


        printf ("%f",fahrenheit);




     }
