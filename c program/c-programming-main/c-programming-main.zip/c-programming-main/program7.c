#include <stdio.h>
int main(){
int n;
printf("enter a number");
scanf("%d",&n);
if (n%3==0&&n%7==0){
    printf("divisible by both 3 & 4");
}else{
printf("not divisible by both number");
 } }
