#include <stdio.h>
int main(){
    int a;
    int b;
    int c;
    int sum;

    printf("enter a number");
    scanf("%d",&a);
    printf("enter a number");
    scanf("%d",&b);
    printf("enter a number");
    scanf("%d",&c);

    sum=a+b+c;

    printf("sum");
    printf("%d",sum);





}
