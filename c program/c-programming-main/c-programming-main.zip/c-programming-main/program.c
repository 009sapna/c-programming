#include <stdio.h>
int main(){
int n;
int r;
printf("enter a number");
scanf("%d",&n);
r= n%10;
if (r==5){
    printf("yes");
}else{
printf("no");
}}
