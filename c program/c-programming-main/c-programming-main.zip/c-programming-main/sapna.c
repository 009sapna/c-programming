#include <stdio.h>
int main (){
int a;
int b;
int c;
float d;
printf("enter the first value");
scanf("%d",&a);
printf("enter the second value");
scanf("%d",&b);
printf("enter the third value");
scanf("%d",&c);
d=(a+b+c)/3;
printf("%f",d);
}
