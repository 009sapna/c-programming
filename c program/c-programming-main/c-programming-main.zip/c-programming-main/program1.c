#include <stdio.h>
int main(){
int n;
int r;
printf("enter a number");
scanf("%d",&n);
if (r=n%2==0){
    printf("yes");
}else{
printf("no");
 } }
