#include <stdio.h>
int main(){
    int hours;
    int minutes;
    int total_minutes;
    printf("enter the number of hours: \t");
    scanf("%d",& hours);
    printf("enter the number of minutes: \t");
    scanf("%d",&minutes);

    total_minutes=(hours*60)+minutes;
    printf("total_minutes");
    printf("%d",total_minutes);







}
