#include <stdio.h>
int main(){
int n;
printf("enter a number");
scanf("%d",&n);
if(n%3==0 && n%7==0){
    printf("divisible");
}else{
printf("not divisible");
}
}
