#include <stdio.h>
int main(){
int n;
int x;
printf("enter a number:");
scanf("%d",&n);
(n%2==0)?
printf("%d",(x=n*n)): printf("%d",(x=n*n*n));

       }
